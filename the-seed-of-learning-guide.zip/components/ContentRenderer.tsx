
import React from 'react';
import { ContentItem } from '../types';

interface ContentRendererProps {
  item: ContentItem;
}

const ContentRenderer: React.FC<ContentRendererProps> = ({ item }) => {
  switch (item.type) {
    case 'paragraph':
      return <p className="mb-4 text-stone-700 leading-relaxed">{item.text}</p>;
    case 'quote':
      return (
        <blockquote className="my-6 p-4 border-l-4 border-emerald-500 bg-lime-50 italic text-stone-600 rounded-r-md">
          <p className="leading-relaxed">"{item.text}"</p>
        </blockquote>
      );
    case 'highlight':
      return (
        <div className="my-5 p-4 bg-amber-100 border border-amber-300 rounded-md">
          <p className="font-medium text-amber-700">{item.text}</p>
        </div>
      );
    case 'list':
      return (
        <ul className="list-disc list-inside mb-4 pl-4 text-stone-700 space-y-2 leading-relaxed">
          {item.items?.map((listItem, index) => (
            <li key={index}>{listItem}</li>
          ))}
        </ul>
      );
    default:
      return null;
  }
};

export default ContentRenderer;
