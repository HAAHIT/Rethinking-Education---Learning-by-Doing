
import React, { useEffect } from 'react';
import { BOOK_CONTENT } from '../constants';
import ContentRenderer from './ContentRenderer';

const HomeView: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="space-y-10">
      <header className="text-center py-8">
        <h1 className="text-4xl md:text-5xl font-bold text-emerald-700 mb-3">{BOOK_CONTENT.title}</h1>
        <p className="text-lg md:text-xl text-amber-700 italic">{BOOK_CONTENT.subtitle}</p>
      </header>

      <section className="bg-white p-6 md:p-8 rounded-xl shadow-lg border border-lime-200">
        <h2 className="text-2xl font-semibold text-emerald-700 mb-4">Introduction</h2>
        {BOOK_CONTENT.introduction.map((item, index) => (
          <ContentRenderer key={`intro-${index}`} item={item} />
        ))}
      </section>

      <section className="bg-lime-50 p-6 md:p-8 rounded-xl shadow-lg border border-lime-200">
        <h2 className="text-2xl font-semibold text-emerald-700 mb-4">{BOOK_CONTENT.keyElements.title}</h2>
        <ul className="list-disc list-inside space-y-2 text-stone-700 leading-relaxed">
          {BOOK_CONTENT.keyElements.elements.map((element, index) => (
            <li key={`keyel-${index}`}>{element}</li>
          ))}
        </ul>
      </section>

      <section className="bg-white p-6 md:p-8 rounded-xl shadow-lg border border-lime-200">
        <h2 className="text-2xl font-semibold text-emerald-700 mb-4">{BOOK_CONTENT.finalWord.title}</h2>
        {BOOK_CONTENT.finalWord.paragraphs.map((paragraph, index) => (
          <p key={`final-${index}`} className="mb-4 text-stone-700 leading-relaxed">{paragraph}</p>
        ))}
      </section>
    </div>
  );
};

export default HomeView;
