
import React from 'react';
import { Link } from 'react-router-dom';
import Sidebar from './Sidebar';
import BookOpenIcon from './icons/BookOpenIcon';
import { BOOK_CONTENT } from '../constants';


interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="flex flex-col h-screen">
      <header className="bg-emerald-700 text-white p-4 shadow-md fixed top-0 left-0 right-0 z-10">
        <div className="container mx-auto flex items-center">
          <BookOpenIcon className="w-8 h-8 mr-3 text-amber-300" />
          <Link to="/" className="text-2xl font-bold hover:text-amber-200 transition-colors">
            {BOOK_CONTENT.title}
          </Link>
        </div>
      </header>
      <div className="flex flex-1 pt-16"> {/* pt-16 to offset fixed header */}
        <Sidebar />
        <main className="flex-1 p-6 md:p-8 overflow-y-auto bg-amber-50">
          <div className="max-w-4xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;
