
import React, { useEffect } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { BOOK_CONTENT } from '../constants';
import { Chapter } from '../types';
import InvitationCard from './InvitationCard';
import ContentRenderer from './ContentRenderer';

const ChapterView: React.FC = () => {
  const { partId, chapterId } = useParams<{ partId: string; chapterId: string }>();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [partId, chapterId]);

  const part = BOOK_CONTENT.parts.find(p => p.id === partId);
  const chapter = part?.chapters.find(c => c.id === chapterId);

  if (!part || !chapter) {
    // Or a more sophisticated "Not Found" component
    return <Navigate to="/" replace />;
  }

  return (
    <article className="prose max-w-none prose-stone prose-headings:text-emerald-700 prose-h1:text-3xl prose-h1:mb-6 prose-h2:text-2xl prose-h2:mt-8 prose-h2:mb-4">
      <h1>{chapter.title}</h1>
      
      {chapter.content.map((item, index) => (
        <ContentRenderer key={index} item={item} />
      ))}

      {chapter.invitations && chapter.invitations.length > 0 && (
        <div className="mt-10">
          <h2 className="text-2xl font-semibold text-emerald-700 mb-6 border-b-2 border-emerald-200 pb-2">
            Invitations to Discover
          </h2>
          {chapter.invitations.map(invitation => (
            <InvitationCard key={invitation.id} invitation={invitation} />
          ))}
        </div>
      )}
    </article>
  );
};

export default ChapterView;
