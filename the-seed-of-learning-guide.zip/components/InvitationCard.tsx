
import React from 'react';
import { Invitation } from '../types';
import SparklesIcon from './icons/SparklesIcon'; // Assuming you have a SparklesIcon

interface InvitationCardProps {
  invitation: Invitation;
}

const InvitationCard: React.FC<InvitationCardProps> = ({ invitation }) => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-amber-300 my-6 hover:shadow-xl transition-shadow duration-300">
      <div className="flex items-center mb-3">
        <SparklesIcon className="w-6 h-6 text-amber-500 mr-3" />
        <h3 className="text-xl font-semibold text-emerald-700">{invitation.name}</h3>
      </div>
      <p className="text-stone-700 mb-4 leading-relaxed">{invitation.description}</p>
      
      <div className="mb-4">
        <h4 className="font-medium text-emerald-600 mb-1">Learning Focus:</h4>
        <ul className="list-disc list-inside pl-2 text-sm text-stone-600 space-y-1">
          {invitation.learningFocus.map((focus, index) => (
            <li key={index}>{focus}</li>
          ))}
        </ul>
      </div>

      <div className="mb-4">
        <h4 className="font-medium text-emerald-600 mb-1">Materials Needed:</h4>
        <ul className="list-disc list-inside pl-2 text-sm text-stone-600 space-y-1">
          {invitation.materialsNeeded.map((material, index) => (
            <li key={index}>{material}</li>
          ))}
        </ul>
      </div>

      {invitation.safetyNotes && (
        <div className="bg-red-50 p-3 rounded-md border border-red-200">
          <h4 className="font-medium text-red-700 mb-1">Safety Notes:</h4>
          <p className="text-sm text-red-600">{invitation.safetyNotes}</p>
        </div>
      )}
    </div>
  );
};

export default InvitationCard;
