
import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { BOOK_CONTENT } from '../constants';
import { Part } from '../types';
import ChevronDownIcon from './icons/ChevronDownIcon';
import ChevronRightIcon from './icons/ChevronRightIcon';

const Sidebar: React.FC = () => {
  const [openParts, setOpenParts] = useState<Record<string, boolean>>(() => {
    // Optionally, open the first part by default
    const initialOpenState: Record<string, boolean> = {};
    if (BOOK_CONTENT.parts.length > 0) {
      initialOpenState[BOOK_CONTENT.parts[0].id] = true;
    }
    return initialOpenState;
  });

  const togglePart = (partId: string) => {
    setOpenParts(prev => ({ ...prev, [partId]: !prev[partId] }));
  };

  return (
    <aside className="w-64 md:w-80 bg-lime-100 p-4 overflow-y-auto shadow-lg border-r border-lime-300">
      <nav>
        <Link 
          to="/" 
          className="block py-2.5 px-4 rounded-lg transition-colors duration-200 font-semibold text-emerald-700 hover:bg-lime-200 mb-4 text-lg"
        >
          Home / Introduction
        </Link>
        <ul>
          {BOOK_CONTENT.parts.map((part: Part) => (
            <li key={part.id} className="mb-3">
              <button
                onClick={() => togglePart(part.id)}
                className="w-full flex items-center justify-between text-left py-2 px-3 rounded-md text-emerald-800 font-semibold hover:bg-lime-200 transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <span>{part.title}</span>
                {openParts[part.id] ? <ChevronDownIcon className="w-5 h-5" /> : <ChevronRightIcon className="w-5 h-5" />}
              </button>
              {openParts[part.id] && (
                <ul className="mt-1 ml-3 pl-3 border-l-2 border-lime-300">
                  {part.chapters.map(chapter => (
                    <li key={chapter.id} className="my-1">
                      <NavLink
                        to={`/part/${part.id}/chapter/${chapter.id}`}
                        className={({ isActive }) =>
                          `block py-1.5 px-3 rounded-md text-sm transition-colors duration-200 ${
                            isActive 
                              ? 'bg-emerald-600 text-white font-medium shadow-sm' 
                              : 'text-emerald-700 hover:bg-lime-200 hover:text-emerald-900'
                          }`
                        }
                      >
                        {chapter.title}
                      </NavLink>
                    </li>
                  ))}
                </ul>
              )}
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
